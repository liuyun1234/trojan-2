## 预览地址
(效果预览)[https://htmlpreview.github.io/?https://github.com/geekape/geek-navigation/blob/master/index.html]

## 演示图
![](./img/nav.gif)

## 提示
Vue+Express+MongoDB版本请查看[Vue2分支](https://github.com/geekape/geek-navigation/tree/vue2?1552117305452)，静态导航将不再更新
